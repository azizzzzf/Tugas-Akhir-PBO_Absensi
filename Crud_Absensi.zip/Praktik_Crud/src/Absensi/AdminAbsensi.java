/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Absensi;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author O M E N
 */
public class AdminAbsensi extends javax.swing.JFrame {

    public AdminAbsensi() {
        initComponents();
        table();
        table3();
    }
    
    void cari (){
        DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("NIM");
        tbl.addColumn("Nama");
        tbl.addColumn("Keterangan");
        
        try {
            String sql = "SELECT * FROM tb_mahasiswa WHERE NIM like '%" + tCari.getText() + "%'";
            Connection con = (Connection) Koneksi.getConnection();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            
            while(rs.next()){
                tbl.addRow(new Object[] {
                    rs.getString("NIM"),
                    rs.getString("Nama"),
                    rs.getString("Keterangan"),               
                });
                jTable1.setModel(tbl);
            }
        } catch (Exception e) {
        }
    }
    
    void cari3(){
        DefaultTableModel tbl3 = new DefaultTableModel();
        tbl3.addColumn("nid");
        tbl3.addColumn("nama");
        tbl3.addColumn("matakuliah");
        tbl3.addColumn("keterangan");
        
        try {
            String sql = "SELECT * FROM tb_dosen WHERE nid like '%" + tCari3.getText() + "%'";
            Connection con = (Connection) Koneksi.getConnection();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            
            while(rs.next()){
                tbl3.addRow(new Object[] {
                    rs.getString("nid"),
                    rs.getString("nama"),
                    rs.getString("matakuliah"),
                    rs.getString("keterangan"),
                });
                jTable3.setModel(tbl3);
            }
        } catch (Exception e) {
        }
    }
    
    void hapus(){
        tNim.setText("");
        tNama.setText("");
        tNid3.setText("");
        tNama3.setText("");
        tMatkul3.setText("");
               
    }
    
    public void table() {
        DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("NIM");
        tbl.addColumn("Nama");
        tbl.addColumn("Keterangan");
        
        try {
            Statement st = (Statement) Koneksi.getConnection().createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM tb_mahasiswa");
            
            while(rs.next()){
                tbl.addRow(new Object[] {
                    rs.getString("NIM"),
                    rs.getString("Nama"),
                    rs.getString("Keterangan"),               
                });
                jTable1.setModel(tbl);
            }
            JOptionPane.showMessageDialog(null, "Database Connection Successful");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Database Connection Failed" + e.getMessage());
        }
    }
    
    public void table3() {
        DefaultTableModel tbl3 = new DefaultTableModel();
        tbl3.addColumn("nid");
        tbl3.addColumn("nama");
        tbl3.addColumn("matakuliah");
        tbl3.addColumn("keterangan");
        
        try {
            Statement st = (Statement) Koneksi.getConnection().createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM tb_dosen");
            
            while(rs.next()){
                tbl3.addRow(new Object[] {
                    rs.getString("nid"),
                    rs.getString("nama"),
                    rs.getString("matakuliah"),
                    rs.getString("keterangan")
                });
                jTable3.setModel(tbl3);
            }
        } catch (Exception e) {           
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jCheckBoxMenuItem1 = new javax.swing.JCheckBoxMenuItem();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        tNim = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        tNama = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        rHadir = new javax.swing.JRadioButton();
        rTHadir = new javax.swing.JRadioButton();
        bSimpan = new javax.swing.JButton();
        bTampilkan = new javax.swing.JButton();
        bEdit = new javax.swing.JButton();
        bCari = new javax.swing.JButton();
        tCari = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        bHapus = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        tNid3 = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        tNama3 = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        rHadir3 = new javax.swing.JRadioButton();
        rTHadir3 = new javax.swing.JRadioButton();
        jLabel8 = new javax.swing.JLabel();
        tMatkul3 = new javax.swing.JTextField();
        bSimpan3 = new javax.swing.JButton();
        bHapus3 = new javax.swing.JButton();
        bEdit3 = new javax.swing.JButton();
        bTampilkan3 = new javax.swing.JButton();
        bCari3 = new javax.swing.JButton();
        tCari3 = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();

        jCheckBoxMenuItem1.setSelected(true);
        jCheckBoxMenuItem1.setText("jCheckBoxMenuItem1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(153, 255, 204));

        jPanel1.setBackground(new java.awt.Color(153, 255, 204));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setText("ADMIN PRESENSI");

        tNim.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tNimActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        jLabel2.setText("NIM");

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        jLabel3.setText("Nama");

        tNama.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tNamaActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        jLabel4.setText("Keterangan");

        rHadir.setBackground(new java.awt.Color(153, 255, 204));
        rHadir.setText("Hadir");
        rHadir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rHadirActionPerformed(evt);
            }
        });

        rTHadir.setBackground(new java.awt.Color(153, 255, 204));
        rTHadir.setText("Tidak Hadir");

        bSimpan.setText("Simpan");
        bSimpan.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bSimpanMouseClicked(evt);
            }
        });
        bSimpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bSimpanActionPerformed(evt);
            }
        });

        bTampilkan.setText("Tampilkan");
        bTampilkan.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bTampilkanMouseClicked(evt);
            }
        });
        bTampilkan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bTampilkanActionPerformed(evt);
            }
        });

        bEdit.setText("Edit");
        bEdit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bEditMouseClicked(evt);
            }
        });
        bEdit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bEditActionPerformed(evt);
            }
        });

        bCari.setText("Cari NIM");
        bCari.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bCariMouseClicked(evt);
            }
        });
        bCari.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bCariActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "NIM", "Nama", "Keterangan"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        bHapus.setText("Hapus");
        bHapus.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bHapusMouseClicked(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        jLabel5.setText("NID");

        tNid3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tNid3ActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        jLabel6.setText("Nama");

        tNama3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tNama3ActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        jLabel7.setText("Keterangan");

        rHadir3.setBackground(new java.awt.Color(153, 255, 204));
        rHadir3.setText("Hadir");
        rHadir3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rHadir3ActionPerformed(evt);
            }
        });

        rTHadir3.setBackground(new java.awt.Color(153, 255, 204));
        rTHadir3.setText("Tidak Hadir");
        rTHadir3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rTHadir3ActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        jLabel8.setText("Mata Kuliah");

        bSimpan3.setText("Simpan");
        bSimpan3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bSimpan3MouseClicked(evt);
            }
        });
        bSimpan3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bSimpan3ActionPerformed(evt);
            }
        });

        bHapus3.setText("Hapus");
        bHapus3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bHapus3MouseClicked(evt);
            }
        });

        bEdit3.setText("Edit");
        bEdit3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bEdit3MouseClicked(evt);
            }
        });
        bEdit3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bEdit3ActionPerformed(evt);
            }
        });

        bTampilkan3.setText("Tampilkan");
        bTampilkan3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bTampilkan3MouseClicked(evt);
            }
        });
        bTampilkan3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bTampilkan3ActionPerformed(evt);
            }
        });

        bCari3.setText("Cari NID");
        bCari3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bCari3MouseClicked(evt);
            }
        });
        bCari3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bCari3ActionPerformed(evt);
            }
        });

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(jTable2);

        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "NID", "Nama", "Mata Kuliah", "Keterangan"
            }
        ));
        jTable3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable3MouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(jTable3);

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel9.setText("MAHASISWA");

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel10.setText("DOSEN");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3))
                        .addGap(50, 50, 50)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(tNama, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tNim, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel9)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(rTHadir)
                            .addComponent(rHadir)))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addComponent(bCari, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(52, 52, 52)
                            .addComponent(tCari, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(bSimpan, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(bHapus, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGap(64, 64, 64)
                            .addComponent(bEdit, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addComponent(bTampilkan)))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 475, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 263, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGap(1, 1, 1)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(bHapus3, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(bSimpan3))
                                .addComponent(bCari3, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 475, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel8)
                                .addComponent(jLabel7)
                                .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.LEADING))
                            .addGap(59, 59, 59)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(tNid3, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tNama3, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tMatkul3, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(rHadir3)
                                .addComponent(rTHadir3)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(tCari3, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                        .addComponent(bEdit3, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(bTampilkan3, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                            .addComponent(jLabel10)
                            .addGap(161, 161, 161)))
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(34, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(572, 572, 572))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(jLabel10))
                .addGap(56, 56, 56)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(tNim, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(tNid3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(tNama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tNama3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(rHadir)
                    .addComponent(tMatkul3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(rTHadir)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(rHadir3))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(bSimpan)
                            .addComponent(bEdit)
                            .addComponent(bTampilkan)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(rTHadir3)
                        .addGap(13, 13, 13)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(bSimpan3)
                            .addComponent(bEdit3)
                            .addComponent(bTampilkan3))))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(bHapus)
                    .addComponent(bHapus3))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(72, 72, 72)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(bCari)
                            .addComponent(tCari, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(bCari3)
                            .addComponent(tCari3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(33, 33, 33)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                        .addGap(444, 444, 444))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 209, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 209, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 733, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void rHadirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rHadirActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rHadirActionPerformed

    private void tNimActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tNimActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tNimActionPerformed

    private void bSimpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bSimpanActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_bSimpanActionPerformed

    private void bEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bEditActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_bEditActionPerformed

    private void tNamaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tNamaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tNamaActionPerformed

    private void bSimpanMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bSimpanMouseClicked
        // TODO add your handling code here:
        String jk = null;
        
        if(rHadir.isSelected()){
            
            jk = "Hadir";
        } else if(rTHadir.isSelected()) {
            jk = "Tidak Hadir";
        }
        
        try {
            String sql = "INSERT INTO tb_mahasiswa VALUES ('" + tNim.getText() + "','"
                    + tNama.getText() + "','" + jk + "')";
            Connection con = (Connection) Koneksi.getConnection();
            PreparedStatement pst = con.prepareStatement(sql);
            pst.execute();
            
            JOptionPane.showMessageDialog(null, "Successfully Added");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Failed" + e.getMessage());
        }
    }//GEN-LAST:event_bSimpanMouseClicked

    private void bTampilkanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bTampilkanActionPerformed
        // TODO add your handling code here:
        
        try {
            String sql = "SELECT * FROM tb_mahasiswa WHERE NIM ='" + tNim.getText() + "'";
            Connection con = (Connection) Koneksi.getConnection();
            PreparedStatement pst = con.prepareStatement(sql);
            pst.execute();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
        table();
        hapus();
    }//GEN-LAST:event_bTampilkanActionPerformed

    private void bHapusMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bHapusMouseClicked
        // TODO add your handling code here:
        
        try {
            String sql = "DELETE FROM tb_mahasiswa WHERE NIM='" + tNim.getText() + "'";
            Connection con = (Connection) Koneksi.getConnection();
            PreparedStatement pst = con.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(null, "Delete Successful");
        } catch (Exception e) {
        }
        
    }//GEN-LAST:event_bHapusMouseClicked

    private void bTampilkanMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bTampilkanMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_bTampilkanMouseClicked

    private void bEditMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bEditMouseClicked
        // TODO add your handling code here:
        String jk = null;
        
        if(rHadir.isSelected()){
            
            jk = "Hadir";
        } else if(rTHadir.isSelected()) {
            jk = "Tidak Hadir";
        }
        
        try {
            String sql = "UPDATE tb_mahasiswa SET NIM='" + tNim.getText() + "',Nama ='" + tNama.getText()
                    + "',Keterangan='" + jk + "' WHERE NIM='" + tNim.getText() + "'";
            Connection con = (Connection) Koneksi.getConnection();
            PreparedStatement pst = con.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(null, "Edit Successful");
        } catch (Exception e) {
        }
    }//GEN-LAST:event_bEditMouseClicked

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        int baris;
        baris = jTable1.rowAtPoint(evt.getPoint());
        String NIM = jTable1.getValueAt(baris, 0).toString();
        tNim.setText(NIM);
        String Nama = jTable1.getValueAt(baris, 1).toString();
        tNama.setText(Nama);    
    }//GEN-LAST:event_jTable1MouseClicked

    private void bCariActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bCariActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_bCariActionPerformed

    private void bCariMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bCariMouseClicked
        // TODO add your handling code here:
        cari();
    }//GEN-LAST:event_bCariMouseClicked

    private void tNid3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tNid3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tNid3ActionPerformed

    private void tNama3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tNama3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tNama3ActionPerformed

    private void rHadir3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rHadir3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rHadir3ActionPerformed

    private void rTHadir3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rTHadir3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rTHadir3ActionPerformed

    private void bSimpan3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bSimpan3MouseClicked
        // TODO add your handling code here:
        String jk = null;
        
        if(rHadir3.isSelected()){
            
            jk = "Hadir";
        } else if(rTHadir3.isSelected()) {
            jk = "Tidak Hadir";
        }
        
        try {
            String sql = "INSERT INTO tb_dosen VALUES ('" + tNid3.getText() + "','"
                    + tNama3.getText() + "','" + tMatkul3.getText() + "','" + jk + "')";
            Connection con = (Connection) Koneksi.getConnection();
            PreparedStatement pst = con.prepareStatement(sql);
            pst.execute();
            
            JOptionPane.showMessageDialog(null, "Successfully Added");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Failed" + e.getMessage());
        }
    }//GEN-LAST:event_bSimpan3MouseClicked

    private void bSimpan3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bSimpan3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_bSimpan3ActionPerformed

    private void bHapus3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bHapus3MouseClicked
        // TODO add your handling code here:
        try {
            String sql = "DELETE FROM tb_dosen WHERE nid ='" + tNid3.getText() + "'";
        Connection con = (Connection) Koneksi.getConnection();
        PreparedStatement pst = con.prepareStatement(sql);
        pst.execute();
        JOptionPane.showMessageDialog(rootPane, "Delete Successful");
        } catch (Exception e) {
        }
    }//GEN-LAST:event_bHapus3MouseClicked

    private void bEdit3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bEdit3MouseClicked
        // TODO add your handling code here:
        String jk = null;
        
        if(rHadir3.isSelected()){
            
            jk = "Hadir";
        } else if(rTHadir3.isSelected()) {
            jk = "Tidak Hadir";
        }
        
        try {
            String sql = "UPDATE tb_dosen SET nid='" + tNid3.getText() + "',nama ='" + tNama3.getText()
                    + "',matakuliah='" + tMatkul3.getText() + "',keterangan='" + jk + "' WHERE nid='" + tNid3.getText() + "'";
            Connection con = (Connection) Koneksi.getConnection();
            PreparedStatement pst = con.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(rootPane, "Edit Successful");
        } catch (Exception e) {
        }
    }//GEN-LAST:event_bEdit3MouseClicked

    private void bEdit3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bEdit3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_bEdit3ActionPerformed

    private void bTampilkan3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bTampilkan3MouseClicked
        // TODO add your handling code here:
        
        try {
            String sql = "SELECT * FROM tb_dosen WHERE nid ='" + tNid3.getText() + "'";
            Connection con = (Connection) Koneksi.getConnection();
            PreparedStatement pst = con.prepareStatement(sql);
            pst.execute();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
        table3();
        hapus();
    }//GEN-LAST:event_bTampilkan3MouseClicked

    private void bTampilkan3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bTampilkan3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_bTampilkan3ActionPerformed

    private void bCari3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bCari3MouseClicked
        // TODO add your handling code here:
        cari3();
    }//GEN-LAST:event_bCari3MouseClicked

    private void bCari3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bCari3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_bCari3ActionPerformed

    private void jTable3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable3MouseClicked
        // TODO add your handling code here:
        
        int baris = jTable3.rowAtPoint(evt.getPoint());
        String nid = jTable3.getValueAt(baris, 0).toString();
        tNid3.setText(nid);
        String nama = jTable3.getValueAt(baris, 1).toString();
        tNama3.setText(nama);
        String matakuliah = jTable3.getValueAt(baris, 2).toString();
        tMatkul3.setText(matakuliah);
    }//GEN-LAST:event_jTable3MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AdminAbsensi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AdminAbsensi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AdminAbsensi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AdminAbsensi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AdminAbsensi().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bCari;
    private javax.swing.JButton bCari3;
    private javax.swing.JButton bEdit;
    private javax.swing.JButton bEdit3;
    private javax.swing.JButton bHapus;
    private javax.swing.JButton bHapus3;
    private javax.swing.JButton bSimpan;
    private javax.swing.JButton bSimpan3;
    private javax.swing.JButton bTampilkan;
    private javax.swing.JButton bTampilkan3;
    private javax.swing.JCheckBoxMenuItem jCheckBoxMenuItem1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable3;
    private javax.swing.JRadioButton rHadir;
    private javax.swing.JRadioButton rHadir3;
    private javax.swing.JRadioButton rTHadir;
    private javax.swing.JRadioButton rTHadir3;
    private javax.swing.JTextField tCari;
    private javax.swing.JTextField tCari3;
    private javax.swing.JTextField tMatkul3;
    private javax.swing.JTextField tNama;
    private javax.swing.JTextField tNama3;
    private javax.swing.JTextField tNid3;
    private javax.swing.JTextField tNim;
    // End of variables declaration//GEN-END:variables
}
